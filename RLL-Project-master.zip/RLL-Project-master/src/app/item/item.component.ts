import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/models/customer';
import { ItemService } from 'src/services/item.service';
import { Item } from '../models/ItemModel';

@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.css']
})
export class ItemComponent implements OnInit {


  itemNumber: number = 0;
  productId: number = 0;
  itemName: string = '';
  desc: string = '';
  status: number = 0;
  discount: number = 0;
  quantity: number = 0;
  unitPrice: number = 0;
  totalStock: number = 0;
  customerId: number = 1;
  selectedItemId:any='--only for update operation--';

  itemIds:number[]=[];
  constructor(private itemService: ItemService) { }


  ngOnInit(): void {
    this.loadData();
  }

  loadData(){
    this.itemIds=[];
    this.itemService.getItemById().subscribe((item: Item[]) => {
      item.forEach((p: Item) => {
        this.itemIds.push(p.id);
      });
    })
  }

  calculatePrice() {
    this.totalStock = this.quantity * this.unitPrice;
  }
  addItem() {
    if ((this.itemName != ''&& this.itemName!=undefined) && (this.itemNumber != 0 && this.itemNumber!=undefined) && (this.productId != null && this.productId!=undefined) && (this.quantity != 0 && this.quantity!=undefined) && (this.unitPrice != 0 && this.unitPrice!=undefined) && (this.desc != '' && this.desc!=undefined) && (this.customerId!=undefined && this.customerId>0)) {
    const c = new Customer();
    c.id = this.customerId;
    const item = new Item(c);
    item.itemName = this.itemName;
    item.itemNumber = this.itemNumber;
    item.productId = this.productId;
    item.quantity = this.quantity;
    // item.totalPrice = this.totalStock;
    item.totalPrice = this.totalStock = this.quantity * this.unitPrice;
    item.unitPrice = this.unitPrice;
    item.description = this.desc;
    //item.status = this.status;
    this.itemService.registerItem(item).subscribe((resp: any) => {
      alert('Item Added Sucessfully !!')
      this.selectedItemId='--only for update operation--';
      this.customerId=0;
      this.itemName='';
      this.itemNumber=0;
      this.productId=0;
      this.quantity=0;
      this.totalStock=0;
      this.unitPrice=0;
      this.desc='';
      this.status=0;
    })
  }else{
    alert("Enter all Details")
  }
    // this.snackbar.open('Item Succefully','close')
  }

  update() {
    
    const c = new Customer();
    c.id = this.customerId;
    const item = new Item(c);
    item.itemName = this.itemName;
    item.itemNumber = this.itemNumber;
    item.productId = this.productId;
    item.quantity = this.quantity;
    // item.totalPrice = this.totalStock;
    item.totalPrice = this.totalStock = this.quantity * this.unitPrice;
    item.unitPrice = this.unitPrice;
    item.description = this.desc;
    // item.status = this.status;
    this.itemService.ItemItem(this.selectedItemId, item).subscribe((resp:any)=>{
      alert('Item Updated Sucessfully !!')
      this.selectedItemId='--only for update operation--';
      this.customerId=0;
      this.itemName='';
      this.itemNumber=0;
      this.productId=0;
      this.quantity=0;
      this.totalStock=0;
      this.unitPrice=0;
      this.desc='';
      this.status=0;
    })
  }

  delete() {
    this.itemService.delete(this.selectedItemId).subscribe((resp: any) => {
      alert('Item Deleted Sucessfully !!');
      this.selectedItemId = '--only for update operation--';
      this.loadData();
    })
    // this.snackbar.open('Purchase Added Succefully','close')
  }

  clear(){
    this.customerId=1;
    this.itemName='';
    this.itemNumber=0;
    this.productId=0;
    this.quantity=0;
    this.totalStock=0;
    this.unitPrice=0;
    this.desc='';
    this.status=0;
    this.selectedItemId='--only for update operation--';
  }
}
