import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/models/customer';
import { Sales } from 'src/models/sales';
import { SalesService } from 'src/services/sales.service';

@Component({
  selector: 'app-sale',
  templateUrl: './sale.component.html',
  styleUrls: ['./sale.component.css']
})
export class SaleComponent implements OnInit {

  itemNumber:number=0;
  saleDate:Date=new Date();
  saleId:number=0;
  itemName:string='';
  currentStock:number=0;
  customerName:string='';
  customerId:number=1;
  quantity:number=0;
  unitPrice:number=0;
  totalPrice:number=0;
  selectedSaleId:any='--only for update operation--';
  
  salesIds:number[]=[];
  constructor(private salesService: SalesService) { }

  ngOnInit(): void {
    this.loadData();
  }

  loadData(){
    this.salesIds=[];
    this.salesService.getSalesByIds().subscribe((sales: Sales[]) => {
      sales.forEach((p: Sales) => {
        this.salesIds.push(p.id);
      });
    })
  }

  calculatePrice(){
    this.totalPrice = this.unitPrice* this.quantity;
  }
  addSales()
  {
    if ((this.itemName != ''&& this.itemName!=undefined) && (this.itemNumber != 0 && this.itemNumber!=undefined) && (this.saleId != null && this.saleId!=undefined) && (this.quantity != 0 && this.quantity!=undefined) && (this.unitPrice != 0 && this.unitPrice!=undefined) && (this.saleDate != null && this.saleDate !=undefined) && (this.customerId!=undefined && this.customerId>0)) {
    const c = new Customer();
    c.id = this.customerId;
    const p = new Sales(c);
    p.itemName = this.itemName;
    p.itemNumber = this.itemNumber;
    p.saleId = this.saleId;
    p.quantity = this.quantity;
    p.saleDate = this.saleDate;
    p.unitPrice = this.unitPrice;
    p.totalStock = this.unitPrice* this.quantity;
    p.customerName = this.customerName;
   
    p.totalPrice = this.totalPrice;

    this.salesService.registerSales(p).subscribe((resp:any)=>{

      alert('Sale Added Sucessfully !!')
      this.itemName='';
      this.itemNumber=0;
      this.saleId=0;
      this.quantity=0;
      this.saleDate=new Date();
      this.unitPrice=0;
      this.currentStock=0;
      this.customerId=1;
      this.customerName='';
      this.totalPrice=0;
      this.selectedSaleId='--only for update operation--';
    })
  }else{
    alert("Enter all Details")
  }
  }

  update()
  {
    const c = new Customer();
    c.id = this.customerId;
    const p = new Sales(c);
	  p.id=this.selectedSaleId;
    p.itemName = this.itemName;
    p.itemNumber = this.itemNumber;
    p.saleId = this.saleId;
    p.quantity = this.quantity;
    p.saleDate = this.saleDate;
    p.unitPrice = this.unitPrice;
    p.totalStock = this.unitPrice* this.quantity;
    p.customerName = this.customerName;
    
    p.totalPrice =this.totalPrice;
    this.salesService.SalesSales(this.selectedSaleId,p).subscribe((resp:any)=>{
      alert('Sale Updated Sucessfully !!')
      this.selectedSaleId='--only for update operation--';
	    this.selectedSaleId=0;
      this.itemName='';
      this.itemNumber=0;
      this.saleId=0;
      this.quantity=0;
      this.saleDate=new Date();
      this.unitPrice=0;
      this.currentStock=0;
      this.customerId=1;
      this.customerName='';
      this.totalPrice=0;
    })
  }

  delete() {
    this.salesService.delete(this.selectedSaleId).subscribe((resp: any) => {
      alert('Sales Deleted Sucessfully !!');
      this.selectedSaleId = '--only for update operation--';
      this.loadData();
    })
    // this.snackbar.open('Purchase Added Succefully','close')
  }

  clear(){
    this.itemName='';
    this.itemNumber=0;
    this.saleId=0;
    this.quantity=0;
    this.saleDate=new Date();
    this.unitPrice=0;
    this.currentStock=0;
    this.customerId=1;
    this.customerName='';
    this.totalPrice=0;
    this.selectedSaleId='--only for update operation--';
  }
    // this.snackbar.open('Purchase Added Succefully','close')
  }
