import { nullSafeIsEquivalent } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/models/customer';
import { Purchase } from 'src/models/purchase';
import { PurchaseService } from 'src/services/purchase.service';

@Component({
  selector: 'app-purchase',
  templateUrl: './purchase.component.html',
  styleUrls: ['./purchase.component.css']
})
export class PurchaseComponent implements OnInit {

  itemNumber: number = 0;
  purchaseDate: Date = new Date();
  purchaseId: number = 0;
  itemName: string = '';
  currentStock: number = 0;
  vendorName: string = '';
  quantity: number = 0;
  unitPrice: number = 0;
  totalPrice: number = 0;
  totalStock: number = 0;
  customerId:number=1;
  selectedPurchaseId: any = '--only for update operation--';

  purchaseIds: number[] = [];
  constructor(private purchaseService: PurchaseService) { }

  ngOnInit(): void {
    this.loadData();
  }

  loadData(){
    this.purchaseIds=[];
    this.purchaseService.getPurchaseById().subscribe((Purchase: Purchase[]) => {
      Purchase.forEach((p: Purchase) => {
        this.purchaseIds.push(p.id);
      });
    })
  }
  calculatePrice() {
    this.totalPrice = this.unitPrice * this.quantity;
  }
  addPurchase() {
    if ((this.itemName != ''&& this.itemName!=undefined) && (this.itemNumber != 0 && this.itemNumber!=undefined) && (this.purchaseDate != null && this.purchaseDate!=undefined) && (this.quantity != 0 && this.quantity!=undefined) && (this.unitPrice != 0 && this.unitPrice!=undefined) && (this.vendorName != '' && this.vendorName!=undefined) && (this.currentStock != 0 && this.currentStock!=undefined) && (this.customerId!=undefined && this.customerId>0)) {
      const c = new Customer();
      c.id = this.customerId;
      const p = new Purchase(c);
      p.itemName = this.itemName;
      p.purchaseId = this.purchaseId;
      p.itemNumber = this.itemNumber;
      p.saleDate = this.purchaseDate;
      p.quantity = this.quantity;
      p.unitPrice = this.unitPrice;
      p.totalCost = this.unitPrice * this.quantity;
      p.vendorName = this.vendorName;
      p.currentStock = this.currentStock;

      this.purchaseService.registerPurchase(p).subscribe((resp: any) => {

        alert('Purchase Added Sucessfully !!')
        this.selectedPurchaseId = '--only for update operation--';
        this.itemName = '';
        this.purchaseId = 0;
        this.itemNumber = 0;
        this.purchaseDate = new Date();
        this.quantity = 0;
        this.unitPrice = 0;
        this.vendorName = '';
        this.currentStock = 0;
        this.totalPrice = 0;
        this.currentStock = 0;
        this.customerId=1;
      })
    }else{
      alert("Enter all Details")
    }
    // this.snackbar.open('Purchase Added Succefully','close')
  }

  update() {
    const c = new Customer();
    c.id = this.customerId;
    const p = new Purchase(c);
    p.itemName = this.itemName;
    p.purchaseId = this.purchaseId;
    p.itemNumber = this.itemNumber;
    p.saleDate = this.purchaseDate;
    p.quantity = this.quantity;
    p.unitPrice = this.unitPrice;
    p.totalCost = this.unitPrice * this.quantity;
    p.vendorName = this.vendorName;
    p.currentStock = this.currentStock;

    this.purchaseService.PurchasePurchase(this.selectedPurchaseId, p).subscribe((resp: any) => {

      alert('Purchase Added Sucessfully !!')
      this.selectedPurchaseId = '--only for update operation--';
      this.itemName = '';
      this.purchaseId = 0;
      this.itemNumber = 0;
      this.purchaseDate = new Date();
      this.quantity = 0;
      this.unitPrice = 0;
      this.vendorName = '';
      this.currentStock = 0;
      this.totalPrice = 0;
    })
    // this.snackbar.open('Purchase Added Succefully','close')
  }

  delete() {
    this.purchaseService.delete(this.selectedPurchaseId).subscribe((resp: any) => {
      alert('Purchase Deleted Sucessfully !!');
      this.selectedPurchaseId = '--only for update operation--';
      this.loadData();
    })
    // this.snackbar.open('Purchase Added Succefully','close')
  }
  clear() {

    this.itemName = '';
    this.purchaseId = 0;
    this.itemNumber = 0;
    this.purchaseDate = new Date();
    this.quantity = 0;
    this.unitPrice = 0;
    this.vendorName = '';
    this.currentStock = 0;
    this.totalPrice = 0;
    this.selectedPurchaseId = '--only for update operation--';
  }
}
