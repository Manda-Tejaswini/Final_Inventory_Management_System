import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/services/users.service';
import { RegUser } from '../models/RegistrationModel';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private userService: UserService) { }
  name:string='';
  username:string='';
  password:string='';
  confpassword:string='';
  ngOnInit(): void {
  }
  reg()
  {
    if((this.name!=''|| this.name!=undefined) && (this.password!=undefined || this.password!='') 
    && (this.confpassword!='' && this.confpassword!=undefined)){
      if(this.password == this.confpassword){
        
          console.log(this.name);
          const regUser = new RegUser();
          regUser.name = this.name;
          regUser.password = this.password;
          regUser.username = this.username;

          this.userService.registerCustomer(regUser).subscribe((resp:any)=>{
            alert("User Registered Successfully !!");
            this.name='';
            this.password='';
            this.username='';
            this.confpassword='';
          })

      }else{
        alert("passwords do not match")
      }
    }else{
      alert("Enter All Details")
    }
  }
  clear(){
    this.name='';
    this.password='';
    this.username='';
    this.confpassword='';
  }

}