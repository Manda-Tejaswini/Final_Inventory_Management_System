export class RegUser{
    name:string='';
	username:string='';
	password:string='';
}