import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/models/customer';
import { Users } from 'src/models/users';
import { CustomerService } from 'src/services/customer.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  fullname: string = '';
  phone: number = 0;
  phone2: number = 0;
  status: string = '';
  address: string = '';
  address2: string = '';
  email: string = '';
  city: string = '';
  district = '';
  userId: number = 1;
  selectedCustomerId: any = '--only for update operation--';

  customerIds: number[] = [];
  constructor(private customerService: CustomerService) { }

  ngOnInit(): void {
    this.loadData();
  }

  loadData(){
    this.customerIds=[];
    this.customerService.getCustomerIds().subscribe((customers: Customer[]) => {
      customers.forEach((p: Customer) => {
        this.customerIds.push(p.id);
      });
    })
  }
  add() {
    if ((this.email != '' && this.email != undefined) && (this.fullname != '' && this.fullname != undefined) && (this.phone2 != null && this.phone2 != undefined) && (this.phone != null && this.phone != undefined) && (this.address != '' && this.address != undefined) && (this.address2 != '' && this.address2 != undefined) && (this.city != '' && this.city != undefined) && (this.status != undefined && this.status != '') && (this.district != undefined && this.district != '') && (this.userId != undefined && this.userId != null)) {
      const customer = new Customer();
      customer.email = this.email;
      customer.fullName = this.fullname;
      customer.phone2 = this.phone2;
      customer.phoneNumber = this.phone;
      customer.address = this.address;
      customer.address2 = this.address2;
      customer.city = this.city;
      customer.status = this.status;
      customer.district = this.district;
      const user = new Users();
      user.id = this.userId;
      customer.user = user;
      this.customerService.registerCustomer(customer).subscribe((resp: any) => {
        alert("Customer Added Successfully !!");
        this.email = '';
        this.fullname = '';
        this.phone2 = 0;
        this.phone = 0;
        this.address = '';
        this.address2 = '';
        this.city = '';
        this.district = '';
        this.status='';
      })
    } else {
      alert("Enter all Details")
    }
  }

  update() {
    const customer = new Customer();
    customer.id = this.selectedCustomerId;
    customer.email = this.email;
    customer.fullName = this.fullname;
    customer.phone2 = this.phone2;
    customer.phoneNumber = this.phone;
    customer.address = this.address;
    customer.address2 = this.address2;
    customer.city = this.city;
    customer.status = this.status;
    customer.district = this.district;
    const user = new Users();
    user.id = this.userId;
    customer.user = user;
    this.customerService.updateCustomer(this.selectedCustomerId, customer).subscribe((resp: any) => {
      alert("Customer Updated Sucessfully !!");
      this.selectedCustomerId = 0;
      this.status = '';
      this.email = '';
      this.fullname = '';
      this.phone2 = 0;
      this.phone = 0;
      this.address = '';
      this.address2 = '';
      this.city = '';
      this.district = '';
    })
  }

  delete() {
    this.customerService.delete(this.selectedCustomerId).subscribe((resp: any) => {
      alert('Customer Deleted Sucessfully !!');
      this.selectedCustomerId = '--only for update operation--';
      this.loadData();
    })
    // this.snackbar.open('Purchase Added Succefully','close')
  }

  clear() {
    this.selectedCustomerId = '--only for update operation--';
    this.status = '';
    this.email = '';
    this.fullname = '';
    this.phone2 = 0;
    this.phone = 0;
    this.address = '';
    this.address2 = '';
    this.city = '';
    this.district = '';
  }
}
