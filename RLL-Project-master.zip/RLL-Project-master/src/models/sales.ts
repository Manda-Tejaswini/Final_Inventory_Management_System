import { Customer } from "./customer";

export class Sales{
    itemName:String='';
    itemNumber:number=0;
    quantity:number=0;
    vendorName:String='';
    unitPrice:number=0;
    totalStock:number=0;
    totalPrice:number=0;
    saleId:number=0;
    customer:Customer;
    customerName:string='';
    saleDate:Date=new Date();
    id:number=-10;
    constructor(customer:Customer){
        this.customer = customer;
    }
}