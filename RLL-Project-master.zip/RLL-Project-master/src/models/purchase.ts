import { Customer } from "./customer";

export class Purchase{
itemName:String='';
itemNumber:number=0;
quantity:number=0;
vendorName:String='';
unitPrice:number=0;
totalCost:number=0;
purchaseId:number=0;
saleDate:Date=new Date();
currentStock:number=0;
id:number=-10;
customer:Customer;
constructor(customer:Customer){
    this.customer = customer;
}
}