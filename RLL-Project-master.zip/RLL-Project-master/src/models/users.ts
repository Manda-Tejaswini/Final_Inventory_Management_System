export class Users{
    id:number=0;
name:String='';
password:String='';
user_name:String='';
    }