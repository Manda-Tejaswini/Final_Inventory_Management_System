import { Customer } from "./customer";

export class Item{
itemName:String='';
itemNumber:String='';
quantity:String='';
description:String='';
productId:String='';
unitPrice:String='';
totalPrice:String='';
id:number=-10;
}