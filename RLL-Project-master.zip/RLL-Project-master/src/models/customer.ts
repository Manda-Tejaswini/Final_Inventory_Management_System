import { Users } from "./users";

export class Customer {
    fullName:String='';
	phoneNumber:number=-123;
	 phone2:number=-11;
     email:String='';
	 address:String='';
     address2:String='';
     status:String='';
     city:String='';
     district:String='';
     id:number=-10;
     user:Users = new Users();
}
