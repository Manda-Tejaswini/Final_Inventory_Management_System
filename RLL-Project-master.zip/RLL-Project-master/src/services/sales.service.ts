import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Sales } from 'src/models/sales';

@Injectable({
  providedIn: 'root',
})
export class SalesService {
  private regSalesUrl: string =
  'http://localhost:8080/api/v1/sales';
  private logCustomerUrl: string = 'http://localhost:8080/api/v1/user';

  constructor(private _httpClient: HttpClient) {}

  registerSales(s: Sales): any {
    return this._httpClient.post<Sales>(this.regSalesUrl, s);
  }

  // validateSales(value: any) {
  //   return this._httpClient.post<Sales>(this.regSalesUrl, value);
  // }

  getSalesByIds(){
    return this._httpClient.get<Sales[]>(this.regSalesUrl);
  }

  SalesSales(id:number, sales: Sales){
    return this._httpClient.put<Sales>(this.regSalesUrl+'/'+id, sales);
  }

  delete(id:number){
    return this._httpClient.delete(this.regSalesUrl+'/'+id);
  }

}