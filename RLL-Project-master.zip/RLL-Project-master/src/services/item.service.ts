import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Item } from 'src/app/models/ItemModel';

@Injectable({
  providedIn: 'root',
})
export class ItemService {
  private regItemUrl: string =
    'http://localhost:8080/api/v1/items';
  private logCustomerUrl: string = 'http://localhost:8080/api/v1/customers';



  constructor(private _httpClient: HttpClient) { }

  registerItem(item: Item): any {
    return this._httpClient.post<Item>(this.regItemUrl, item);
  }
  validateItem(value: any) {
    return this._httpClient.post<Item>(this.logCustomerUrl, value);
  }

  getItemById() {
    return this._httpClient.get<Item[]>(this.regItemUrl);
  }

  ItemItem(id: number, item: Item) {
    return this._httpClient.put<Item>(this.regItemUrl + '/' + id, item);
  }

  delete(id:number){
    return this._httpClient.delete(this.regItemUrl+'/'+id);
  }
}