import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Purchase } from 'src/models/purchase';

@Injectable({
  providedIn: 'root',
})
export class PurchaseService {
  private regPurchaseUrl: string =
  'http://localhost:8080/api/v1/purchase';
  private logCustomerUrl: string = 'http://localhost:8080/api/v1/purchase';

  

  constructor(private _httpClient: HttpClient) {}

  registerPurchase(p: Purchase): any {
    return this._httpClient.post<Purchase>(this.regPurchaseUrl, p);
  }

  getPurchaseById(){
    return this._httpClient.get<Purchase[]>(this.regPurchaseUrl);
  }

  PurchasePurchase(id:number, purchases: Purchase){
    return this._httpClient.put<Purchase>(this.regPurchaseUrl+'/'+id, purchases);
  }

  delete(id:number){
    return this._httpClient.delete(this.regPurchaseUrl+'/'+id);
  }

  // setCustomerLoggedIn(customerLoggedIn: string) {
  //   this.customerLoggedIn = customerLoggedIn;
  // }
  // getCustomerLoggedIn() {
  //   return this.customerLoggedIn;
  // }
}