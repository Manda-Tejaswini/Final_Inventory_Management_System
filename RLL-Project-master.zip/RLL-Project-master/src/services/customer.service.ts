
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from 'src/models/customer';

@Injectable({
  providedIn: 'root',
})
export class CustomerService {
  private regCustomerUrl: string =
    'http://localhost:8080/api/v1/customers';
  private logCustomerUrl: string = 'http://localhost:8080/api/v1/customers';

  constructor(private _httpClient: HttpClient) { }

  registerCustomer(customer: Customer): any {
    return this._httpClient.post<Customer>(this.regCustomerUrl, customer);
  }

  validateCustomer(value: any) {
    return this._httpClient.post<Customer>(this.logCustomerUrl, value);
  }

  getCustomerIds() {
    return this._httpClient.get<Customer[]>(this.regCustomerUrl);
  }

  updateCustomer(id: number, customer: Customer) {
    return this._httpClient.put<Customer>(this.regCustomerUrl + '/' + id, customer);
  }

  
  delete(id:number){
    return this._httpClient.delete(this.regCustomerUrl+'/'+id);
  }
  // setCustomerLoggedIn(customerLoggedIn: string) {
  //   this.customerLoggedIn = customerLoggedIn;
  // }
  // getCustomerLoggedIn() {
  //   return this.customerLoggedIn;
  // }
}
