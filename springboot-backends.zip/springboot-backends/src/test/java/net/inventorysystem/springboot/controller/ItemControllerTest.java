package net.inventorysystem.springboot.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.inventorysystem.springboot.controller.ItemController;
import com.inventorysystem.springboot.exception.ResourceNotFoundException;
import com.inventorysystem.springboot.model.Item;
import com.inventorysystem.springboot.repository.ItemRepository;

@ExtendWith(MockitoExtension.class)
public class ItemControllerTest {


	@Mock
	ItemRepository itemRepository;
	
	@InjectMocks
	ItemController itemController;
	
	@Test
	public void testGetAllitems() {
		when(itemRepository.findAll()).thenReturn(getitem());
		List<Item> res = itemController.getAllItem();
		assertEquals(res.size(),1);
	}
	
	@Test
	public void testGetItemById() {
		when(itemRepository.findById(anyLong())).thenReturn(Optional.of(getitem().get(0)));
		ResponseEntity<Item>  resp = itemController.getItemById(1L);
		assertTrue(resp.getStatusCode().equals(HttpStatus.OK));
	}
	
	@Test
	public void testGetcustomerById_fail() {
		when(itemRepository.findById(anyLong())).thenReturn(Optional.empty());
		ResourceNotFoundException thrown = assertThrows(ResourceNotFoundException.class, ()->itemController.getItemById(1L));
		assertTrue(thrown.getMessage().length()>0);
	}
	
	public List<Item> getitem(){
		List<Item> item = new ArrayList<>();
		Item c = new Item();
		c.setItemName("XYZ");
		c.setDescription("working doll");
		c.setId((long)2);
		c.setItemNumber(1234);
		c.setProductId(2);
		c.setQuantity(10);
		c.setUnitPrice((long)10);
		c.setTotalPrice(100);
		item.add(c);
		return item;
	}
}
