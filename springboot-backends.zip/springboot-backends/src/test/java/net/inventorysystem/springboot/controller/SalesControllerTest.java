package net.inventorysystem.springboot.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.inventorysystem.springboot.controller.SalesController;
import com.inventorysystem.springboot.exception.ResourceNotFoundException;
import com.inventorysystem.springboot.model.Sales;
import com.inventorysystem.springboot.repository.SalesRepository;

@ExtendWith(MockitoExtension.class)
public class SalesControllerTest {

	@Mock
	SalesRepository salesRepository;
	
	@InjectMocks
	SalesController salesController;
	
	@Test
	public void testGetAllcustomers() {
		when(salesRepository.findAll()).thenReturn(getSales());
		List<Sales> res = salesController.getAllSales();
		assertEquals(res.size(),1);
	}
	
	@Test
	public void testGetcustomerById() {
		when(salesRepository.findById(anyLong())).thenReturn(Optional.of(getSales().get(0)));
		ResponseEntity<Sales>  resp =salesController.getSalesById(1L);
		assertTrue(resp.getStatusCode().equals(HttpStatus.OK));
	}
	
	@Test
	public void testGetcustomerById_fail() {
		when(salesRepository.findById(anyLong())).thenReturn(Optional.empty());
		ResourceNotFoundException thrown = assertThrows(ResourceNotFoundException.class, ()->salesController.getSalesById(1L));
		assertTrue(thrown.getMessage().length()>0);
	}
	
	public List<Sales> getSales(){
		List<Sales> sales = new ArrayList<>();
		Sales s = new Sales();
		s.setCustomerName("Pooja");
		s.setItemName("Doll");
		//s.setCustomerId(2);
		s.setDiscount((long) 20);
		s.setId((long) 30);
		s.setItemNumber(2);
		s.setQuantity(10);
		s.setTotalStock((long) 20);
		s.setUnitPrice((long)30);
		s.setSaleDate(null);
		s.setSaleId(2);
		sales.add(s);
		return sales;
	}
}
