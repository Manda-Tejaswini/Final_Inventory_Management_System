package net.inventorysystem.springboot.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.inventorysystem.springboot.controller.PurchaseController;
import com.inventorysystem.springboot.exception.ResourceNotFoundException;
import com.inventorysystem.springboot.model.Purchase;
import com.inventorysystem.springboot.repository.PurchaseRepository;

@ExtendWith(MockitoExtension.class)
public class PurchaseControllerTest {

	@Mock
	PurchaseRepository PurchaseRepository;
	
	@InjectMocks
	PurchaseController purchaseController;
	
	
	@Test
	public void testGetAllPurchase() {
		when(PurchaseRepository.findAll()).thenReturn(getPurc());
		List<Purchase> res = purchaseController.getAllPurchase();
		assertEquals(res.size(),1);
	}
	
	@Test
	public void testGetpurchaseById() {
		when(PurchaseRepository.findById(anyLong())).thenReturn(Optional.of(getPurc().get(0)));
		ResponseEntity<Purchase>  resp =purchaseController.getPurchaseById(1L);
		assertTrue(resp.getStatusCode().equals(HttpStatus.OK));
	}
	
	@Test
	public void testGetcustomerById_fail() {
		when(PurchaseRepository.findById(anyLong())).thenReturn(Optional.empty());
		ResourceNotFoundException thrown = assertThrows(ResourceNotFoundException.class, ()->purchaseController.getPurchaseById(1L));
		assertTrue(thrown.getMessage().length()>0);
	}
	
	
	public List<Purchase> getPurc(){
		List<Purchase> Purchase = new ArrayList<>();
		Purchase P = new Purchase();
		P.setCurrentStock(2);
		P.setId(1);
		P.setItemName("doll");
		P.setItemNumber(123);
		P.setPurchaseId(1);
		P.setQuantity((long) 1234);
		P.setSaleDate(null);	
		P.setTotalCost(100);
		P.setVendorName("divya");
		P.setUnityPrice((long) 2);
		Purchase.add(P);
		return Purchase;
	}
}
