package net.inventorysystem.springboot.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.inventorysystem.springboot.controller.UsersController;
import com.inventorysystem.springboot.exception.ResourceNotFoundException;
import com.inventorysystem.springboot.model.Users;
import com.inventorysystem.springboot.repository.UsersRepository;

	@ExtendWith(MockitoExtension.class)
	public class UsersControllerTest {

		@Mock
		UsersRepository usersRepository;
		
		@InjectMocks
		UsersController usersController;
		
		@Test
		public void testGetAllusers() {
			when(usersRepository.findAll()).thenReturn(getUsers());
			List<Users> res = usersController.getAllUsers();
			assertEquals(res.size(),1);
		}
		
		@Test
		public void testGetusersById() {
			when(usersRepository.findById(anyLong())).thenReturn(Optional.of(getUsers().get(0)));
			ResponseEntity<Users>  resp =usersController.getusersById(1L);
			assertTrue(resp.getStatusCode().equals(HttpStatus.OK));
		}
		
		@Test
		public void testGetusersrById_fail() {
			when(usersRepository.findById(anyLong())).thenReturn(Optional.empty());
			ResourceNotFoundException thrown = assertThrows(ResourceNotFoundException.class, ()->usersController.getusersById(1L));
			assertTrue(thrown.getMessage().length()>0);
		}
		
		
		public List<Users> getUsers(){
			List<Users> Users = new ArrayList<>();
			Users u = new Users();
			u.setName("XYZ");
			u.setPassword("121212");
			u.setUsername("divya");
			u.setId((long) 2);
			Users.add(u);
			return Users;
		}
	}


