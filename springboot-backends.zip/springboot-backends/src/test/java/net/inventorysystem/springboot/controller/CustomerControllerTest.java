package net.inventorysystem.springboot.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.inventorysystem.springboot.controller.CustomerController;
import com.inventorysystem.springboot.exception.ResourceNotFoundException;
import com.inventorysystem.springboot.model.Customer;
import com.inventorysystem.springboot.repository.CustomerRepository;

@ExtendWith(MockitoExtension.class)
public class CustomerControllerTest {

	@Mock
	CustomerRepository customerRepository;

	@InjectMocks
	CustomerController customerController;

	@Test
	public void testGetAllcustomers() {
		when(customerRepository.findAll()).thenReturn(getCusts());
		List<Customer> res = customerController.getAllcustomers();
		assertEquals(res.size(), 1);
	}

	@Test
	public void testGetcustomerById() {
		when(customerRepository.findById(anyLong())).thenReturn(Optional.of(getCusts().get(0)));
		ResponseEntity<Customer> resp = customerController.getcustomerById(1L);
		assertTrue(resp.getStatusCode().equals(HttpStatus.OK));
	}

	@Test
	public void testGetcustomerById_fail() {
		when(customerRepository.findById(anyLong())).thenReturn(Optional.empty());
		ResourceNotFoundException thrown = assertThrows(ResourceNotFoundException.class,
				() -> customerController.getcustomerById(1L));
		assertTrue(thrown.getMessage().length() > 0);
	}

	@Test
	public void updatecustomerTest() {
		when(customerRepository.findById(anyLong())).thenReturn(Optional.of(getCusts().get(0)));
		ResponseEntity<Customer> resp = customerController.updatecustomer(1L, new Customer());
		assertTrue(resp.getStatusCode().equals(HttpStatus.OK));
	}

	@Test
	public void deletecustomerTest() {
		when(customerRepository.findById(anyLong())).thenReturn(Optional.of(getCusts().get(0)));
		ResponseEntity<Map<String, Boolean>> resp = customerController.deletecustomer(1L);
		assertTrue(resp.getStatusCode().equals(HttpStatus.OK));
	}
	
	@Test
	public void createcustomerTest() {
//		customerController.createcustomer(new Customer());
//		verify(customerRepository, times(1)).save(any());
	}

	public List<Customer> getCusts() {
		List<Customer> custs = new ArrayList<>();
		Customer c = new Customer();
		c.setFullName("Dinga");
		c.setAddress("hyd");
		c.setAddress2("hyd2");
		c.setCity("sec");
		c.setDistrict("ranga");
		c.setEmail("dinga@gmail");
		c.setId((long) 4);
		c.setPhone2(1234567890);
		c.setStatus("1");
		c.setPhoneNumber(1234567890);
		custs.add(c);
		return custs;
	}

}
